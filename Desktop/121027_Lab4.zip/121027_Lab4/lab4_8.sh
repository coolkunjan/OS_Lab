echo 'Filename of which you want to calculate newline characters'
read a
wc -l $a
