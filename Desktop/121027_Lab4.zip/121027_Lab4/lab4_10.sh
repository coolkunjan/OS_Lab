echo "Enter File Name"
read fn
cat $fn | wc -w
