echo Enter 1st Variable;
read n;
echo You have entered $n;
echo Enter 2nd Variable;
read m;
echo You have entered $m;
echo 1. Addition 2. Subtraction 3. Multiply 4. Division
read choice

case $choice in 

	1) echo Addition
	  echo `expr $n + $m`;;
		
	2) echo Subtraction
	  echo `expr $n - $m`;;
		
	3)echo Multiplication
	  echo `expr $n \* $m`;;
	
	4)echo Division
	  echo `expr $n / $m`;;
	
esac
