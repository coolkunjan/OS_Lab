if [ $2 == '+' ]
then 
echo `expr $1 + $3`

elif [ $2 == '-' ]
then 
echo `expr $1 - $3`

elif [ $2 == '/' ]
then 
echo `expr $1 / $3`

elif [ $2 == 'x' ]
then 
echo `expr $1 \* $3`

fi
