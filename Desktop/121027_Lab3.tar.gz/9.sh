n=1
while [ $n == 1 ]
do
echo Which is the capital city of Gujarat?
read ans

if [ $ans == "gandhinagar" -o $ans == "Gandhinagar" -o $ans == "GANDHINAGAR" ]
then
echo Correct answer...
n=2
else
echo
echo Wrong answer. Read it carefully again..
echo
fi
done

