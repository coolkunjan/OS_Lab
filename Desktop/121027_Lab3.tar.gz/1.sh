echo Enter 1st Variable;
read n;
echo You have entered $n;
echo Enter 2nd Variable;
read m;
echo You have entered $m;
 

	 echo Addition
	  echo `expr $n + $m`;
		
	 echo Subtraction
	  echo `expr $n - $m`;
		
	echo Multiplication
	  echo `expr $n \* $m`;
	
	echo Division
	  echo `expr $n / $m`;
	

