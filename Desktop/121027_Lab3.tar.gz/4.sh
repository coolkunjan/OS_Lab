echo Enter 1st Variable;
read n;
echo Enter 2nd Variable;
read m;

if [ $n -gt $m ]

then

echo $n is greater

elif [ $n -lt $m ]

then

echo $m is greater

elif [ $n == $m ]

then

echo both equal

fi
