echo FIBONACCI SERIES
echo Enter the number of terms you want
read n;
x=0
y=1
k=1
echo $x
echo $y

while [ $n -gt 2 ] 

do

n=`expr $n - $k` 

z=`expr $x + $y`
echo $z
x=$y
y=$z

done
