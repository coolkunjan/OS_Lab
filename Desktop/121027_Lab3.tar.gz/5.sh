c=1;

while [ $c == 1 ]
do
echo Enter Variable;
read n;

if [ $n == "quit" ]
then
c=0;
elif [ $n -lt 50 ]  
then
echo `expr $n \* $n`;
elif [ $n -gt 50 ]  
then
echo Enter num less than 50;

fi

done
