NAME[0]="hello"
NAME[1]="hey"
NAME[2]="how"
NAME[3]="are"
NAME[4]="you"

echo Enter word you want to find
read n
for var in 0 1 2 3 4
do
   if [ ${NAME[$var]}  == $n ]
   then
   echo The word is at index $var
   
   else
   echo word not in list
   exit
   fi
   
done
