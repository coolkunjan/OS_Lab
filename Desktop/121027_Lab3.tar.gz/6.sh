echo Enter command below
read comm
$comm
