s1="jan"
s2="janu"
s3="janua"

echo Enter word;
read m;



if [ $m == $s1 ]

then

echo January

elif [ $m == $s2 ]

then

echo January

elif [ $m == $s3 ]

then

echo January

fi
