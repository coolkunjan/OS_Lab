
n=`expr $1 + 1 `
k=`expr $1 \* $n `
ans=`expr $k / 2 `
echo $ans
 
