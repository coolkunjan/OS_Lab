echo "Enter string:"
read str
y=`expr $str |rev`
if [ "$y" == "$str" ]
then echo "It is a palindrome"
else
echo "Its not a palindrome"
fi
