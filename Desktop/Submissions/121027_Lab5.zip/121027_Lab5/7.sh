echo Enter alphabet
read n
ls  $n*
