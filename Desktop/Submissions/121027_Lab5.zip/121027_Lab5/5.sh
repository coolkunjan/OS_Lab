echo Enter file 1
read n
echo Enter file 2
read m
if [ -e $n ]
then
if [ -e $m ]
then
cat $n>>$m
else
cat $n>$m
fi
fi
