du -hsx * | sort -rh | head -1

